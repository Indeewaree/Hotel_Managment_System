<?php

$conn = mysqli_connect('localhost','root','','hms');
$connection = new mysqli('localhost', 'root', '', 'hms');
?>