

<nav>
	<i class='bx bx-menu'></i>
	<h3><span style="color: white;">Staff Dashboard</span></h3>
	<form action="#">
		<div class="form-input">

		</div>
	</form>

	<a href="">
		<h4><span style="color: red;"><?php echo $_SESSION['staff_name'] ?></span></h4>		
	
	</li>
		

	</a>
<style>
	*{
    text-decoration: none;
}

.overflow-h-menu{
    height: 300px !important;
    overflow-y: scroll;
}
.text-error{
    color: seashell !important;
}
</style>



</nav>
