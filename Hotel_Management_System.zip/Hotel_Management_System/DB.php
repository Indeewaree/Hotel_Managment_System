<?php

//create db connection

$servername="localhost";
$User_Name="root";
$Password="";
$dbname="hms";

$con = mysqli_connect ($servername,$User_Name,$Password,$dbname);

?>
